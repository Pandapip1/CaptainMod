﻿using BepInEx;
using BepInEx.Configuration;
using BepInEx.IL2CPP;
using HarmonyLib;
using Reactor;
using Reactor.Button;
using UnhollowerBaseLib;
using UnityEngine;
using System;
using Hazel;
using System.Reflection;

namespace Pandapip1s_Captain_Mod
{
    enum CustomRPC
    {
        SetCaptain = 69
    }

    [BepInPlugin(Id)]
    [BepInProcess("Among Us.exe")]
    [BepInDependency(ReactorPlugin.Id)]
    public class TemplatePlugin : BasePlugin
    {
        public const string Id = "tk.pandapip1.captainmod";
        internal static int CaptainId = -1;
        public Harmony Harmony { get; } = new Harmony(Id);
        public override void Load()
        {
            Harmony.PatchAll();
        }

        [HarmonyPatch(typeof(HudManager), nameof(HudManager.Start))]
        public static class EmergencyButton
        {
            private static CooldownButton btn;
            public static void Postfix(HudManager __instance)
            {
                btn = new CooldownButton(
                    () =>
                    {
                        PlayerControl.LocalPlayer.CmdReportDeadBody(null);
                    },
                    15f,
                    Properties.Resources.button,
                    new Vector2(0, 1.25f),
                    () =>
                    {
                        return CaptainId == PlayerControl.LocalPlayer.PlayerId && !PlayerControl.LocalPlayer.Data.IsDead;
                    },
                    __instance
                );
            }
        }
        [HarmonyPatch(typeof(HudManager), nameof(HudManager.Start))]
        public static class ZoomButton
        {
            private static CooldownButton btn;
            public static void Postfix(HudManager __instance)
            {
                btn = new CooldownButton(
                    () =>
                    {
                        DestroyableSingleton<HudManager>.Instance.ShadowQuad.gameObject.SetActive(false);
                        Camera.main.orthographicSize = 15f;
                    },
                    30f,
                    Properties.Resources.zoom,
                    new Vector2(0, 0),
                    () =>
                    {
                        return CaptainId == PlayerControl.LocalPlayer.PlayerId && !PlayerControl.LocalPlayer.Data.IsDead && AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started;
                    },
                    __instance,
                    15f,
                    () =>
                    {
                        btn.Timer = btn.MaxTimer;
                        DestroyableSingleton<HudManager>.Instance.ShadowQuad.gameObject.SetActive(!PlayerControl.LocalPlayer.Data.IsDead);
                        Camera.main.orthographicSize = 3f;
                    }
                );
            }
        }
        [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.RpcSetInfected))]
        class SetInfectedPatch
        {
            public static void Postfix(Il2CppReferenceArray<GameData.PlayerInfo> JPGEIBIBJPJ)
            {
                System.Random random = new System.Random();
                PlayerControl cap;
                do
                {
                    cap = PlayerControl.AllPlayerControls[random.Next(PlayerControl.AllPlayerControls.Count)];
                } while (cap.Data.IsImpostor);
                CaptainId = cap.PlayerId;
                MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetCaptain, Hazel.SendOption.None, -1);
                writer.Write(CaptainId);
                AmongUsClient.Instance.FinishRpcImmediately(writer);
            }
        }
        [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.HandleRpc))]
        class HandleRpcPatch
        {
            static void Postfix(byte HKHMBLJFLMC, MessageReader ALMCIJKELCP)
            {
                byte packetId = HKHMBLJFLMC;
                MessageReader reader = ALMCIJKELCP;
                switch (packetId)
                {
                    case (byte)CustomRPC.SetCaptain:
                        CaptainId = reader.ReadByte();
                        break;
                }
            }
        }
        [HarmonyPatch(typeof(IntroCutscene.CoBegin__d), nameof(IntroCutscene.CoBegin__d.MoveNext))]
        public static class IntroCutscenePatch
        {
            public static void Postfix(ref IntroCutscene.CoBegin__d __instance)
            {
                IntroCutscene scene = __instance.__this;
                if (PlayerControl.LocalPlayer.PlayerId == CaptainId)
                {
                    scene.Title.Text = "Captain";
                    scene.Title.Color = Palette.LightBlue;
                    scene.BackgroundBar.material.color = Color.white;
                }
            }
        }
    }
}
